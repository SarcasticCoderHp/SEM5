<?php

$a=10;
$b=20;

if($a===$b) echo "Equal";
else echo "Not Equal";

?>