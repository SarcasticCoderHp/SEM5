<?php

final class Myclass
{
    function a()
    {
        echo "Hello";
    }
}

class Newclass extends Myclass
{};

$obj = new Newclass();
$obj->a();

?>