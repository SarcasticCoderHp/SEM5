<?php

 abstract class fruit
 {
    abstract function color();

 }

 class apple extends fruit
 {
    function color()
    {
        echo "Apple is red";
        echo "<br>";
    }
 }

 class mango extends fruit
 {
    function color()
    {
        echo "Mango is yellow";
    }
 }

 $obj1 = new apple();
 $obj2 = new mango();

 $obj1->color();
 $obj2->color();

 ?>