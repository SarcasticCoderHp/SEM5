<?php

 define("GREETINGS","Hello");
 echo "GREETING";
 echo "<br>";
 echo "grEEting";

 //define("GREETINGS","Hello",TRUE);
 //echo "GREETINGS";
 //echo "<br>";
 //echo "grEEting";

 ?>
