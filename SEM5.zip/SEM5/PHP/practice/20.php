<?php
 
 class Student
 {
    function a()
    {
        echo "Hello from Student";
    }
 }

 class Marks extends Student
 {
    function b()
    {
        echo "Hello from marks";
    }
 }

 $obj = new Marks();
 $obj->a();
 echo "<br>";
 $obj->b();

 ?>