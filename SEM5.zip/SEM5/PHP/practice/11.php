<html>
    <body>
        <form method="POST">
            Enter your id: <input type="number" name="empid"/>
            <br>
            Enter your name: <input type="text" name="empname"/>
             <br>
             <input type="submit" name="submit"/>
        </form>

        <?php

          $empid;
          $empname;

         if(isset($_POST['submit']))
         {
           $empid = $_POST['empid'];
           $empname = $_POST['empname'];
         }

         $fav = array($empid=>$empname);

         foreach($fav as $key=>$value)
         {
            echo "<br>";
            echo "$key is $value";
         }

        ?>

    </body>
</html>