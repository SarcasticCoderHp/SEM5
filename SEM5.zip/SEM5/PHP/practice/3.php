<html>
        <form method="post">
            Enter first number: <input type="number" name="num1"/><br>
            <br>
            Enter second number: <input type="number" name="num2"/><br>
            <br>
            <input type="submit" name="add" value="ADD"><br>
            <br>
            <input type="submit" name="sub" value="SUB"><br>
            <br>
            <input type="submit" name="mul" value="Multiply"><br>
            <br>
            <input type="submit" name="div" value="Divide"><br>

        </form>
        <?php
        if(isset($_POST['add']))
        {
            $number1 = $_POST['num1'];
            $number2 = $_POST['num2'];
            $sum = $number1 + $number2;
            echo "Addition is: $sum";
        }

        else if(isset($_POST['sub']))
        {
            $number1 = $_POST['num1'];
            $number2 = $_POST['num2'];
            $sub = $number1 - $number2;
            echo "Subtraction is: $sub";
        }

        else if(isset($_POST['mul']))
        {
            $number1 = $_POST['num1'];
            $number2 = $_POST['num2'];
            $mul = $number1 * $number2;
            echo "Multiplication is: $mul";
        }

        else if(isset($_POST['div']))
        {
            $number1 = $_POST['num1'];
            $number2 = $_POST['num2'];
            $div = $number1 / $number2;
            echo "Division is: $div";
        }
        ?>
    </body>
</html>