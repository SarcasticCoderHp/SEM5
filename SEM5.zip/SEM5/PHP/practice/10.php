<?php

$favcol = array(1=>'red',2=>'blue',3=>'green');

echo "<br>";

foreach($favcol as $key=>$value)
{
   echo "<br>";
   echo "Favourite color of $key is $value";
}
?>