<?php

function setHeight($minheight = 50)
{
    echo "The height is: $minheight";
}

setHeight();
echo "<br>";
setHeight(150);
echo "<br>";
setHeight(125);

?>