//GET-POST

<html>
    <body>
        <form method="post">
            NAME:<input type="text" name="name"/><br>
            <br>
            Age:<input type="text" name="age"/><br>
            <br>
            <input type="submit" name="submit" value="enter"/>
            </form>
            <?php
             if(isset($_POST['submit']))
             {
                echo "Welcome ".$_POST['name']."<br>";
                echo "You are ".$_POST['age']. " years old"."<br>";
             }
             ?>
    </body>
</html>