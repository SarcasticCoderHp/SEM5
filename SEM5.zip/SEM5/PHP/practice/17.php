<?php

class Hello
{
function __construct()
{
    echo "Constructor";
    echo "<br>";
}

function __destruct()
{
    echo "Destructor";
}
}

$obj = new Hello();

?>