

<?php
 echo "Hello World";
 echo "Hello from the client side";
 ?>