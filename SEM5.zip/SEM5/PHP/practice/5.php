<?php
 $intArray = array(1,2,3,4,5,6,7,8,9,10);

 echo "<br>";

 $count=0;

 echo "Even elements are: ";
 echo "<br>";
 for($i=0;$i<count($intArray);$i++)
 {
    if($intArray[$i]%2==0)
    {
   echo  "$intArray[$i]\n";
   $count = $count + 1;
  } 
}
echo "<br>";
echo "Count is:$count";

?>