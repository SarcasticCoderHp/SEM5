<?php
 class point
 {
    public static $my_static = 'foo';

    public static function do()
    {
        echo point::$my_static;
    }
 }

 echo point::do();

 ?>