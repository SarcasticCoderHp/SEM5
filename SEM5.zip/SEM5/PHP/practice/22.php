<?php

 abstract class base
 {
    abstract function printdata();
 }

 class derived extends base
 {
    function printdata()
    {
        echo "Hello world";
    }
 }

 $obj = new derived();
 $obj->printdata();

 ?>