<?php

include 'C:\xampp\htdocs\PHP';
//require 'C:\xampp\htdocs\PHP';
echo "Rest part of the site";
?>