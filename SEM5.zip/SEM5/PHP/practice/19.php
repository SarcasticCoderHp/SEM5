<html>
    <body>
        <form method="POST">
            Enter name: <input type="text" name="name1"/><br>
            
            Enter color: <input type="text" name="color"/>         <br>
   
            <input type="submit" name="submit"/>
        </form>

        <?php 
         
          $name=$_POST['name1'];
          $color=$_POST['color'];

          $favcolor = array($name=>$color);

          foreach($favcolor as $key=>$value)
          {
            echo "<br>";
            echo "Favcolor of $key is $value";
          }

          ?>
    </body>
</html>