<?php

class employee
{
    public $name;
    public $position;

    function __construct($name,$position)
    {
        $this->name=$name;
        $this->position=$position;
    }

    function show_details()
    {
        echo $this->name;
        echo $this->position;
    }
}

$obj = new employee("Rakesh is"," Manager");
$obj->show_details();

?>