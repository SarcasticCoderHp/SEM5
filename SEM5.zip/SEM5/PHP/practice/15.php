<?php

class demo
{
    function demo()
    {
        echo "User defined constructor";
    }

    function __construct()
    {
        echo "Predefined constructor";
    }
}

$obj = new demo();

?>