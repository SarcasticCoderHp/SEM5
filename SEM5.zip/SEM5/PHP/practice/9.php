<?php
 
 $emp = array(
    array(1," Sonu", 20000),
    array(2," John", 50000),
    array(3," Dave", 35000)
 );

 for($row=0;$row<3;$row++)
 {
    for($col=0;$col<3;$col++)
    {
        echo $emp[$row][$col];
    }
    echo "<br>";
 }
 ?>