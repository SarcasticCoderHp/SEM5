<?php
 $p = array(7,2,10,3,5);
 echo "<br>";

 for($i=0;$i<count($p);$i++)
 {
    echo $p[$i];
 }

 echo "<br>";

 echo "Count of p:".count($p);
 ?>