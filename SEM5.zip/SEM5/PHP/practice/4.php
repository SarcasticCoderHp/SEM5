<?php
 $intArray = array(10,20,30);
 echo "First element: $intArray[0]\n";

 echo "<br>";

 for($i=0;$i<count($intArray);$i++)
 {
   echo "Element[$i]:$intArray[$i]\n <br>";
 }
?>