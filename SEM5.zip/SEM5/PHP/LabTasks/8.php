<?php

$number = 123456;

$count = strlen((string)$number);

echo "Total digits are:$count";

?>