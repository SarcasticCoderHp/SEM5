<html>
    <tr>
        <form method="POST">
            Rollno: <input type="number" name="rollno"/>
            <br>
            <br>
            Name: <input type="text" name="name1"/>
            <br>
            <br>
            Email <input type="email" name="email1"/>
            <br>
            <br>
            <input type="submit" name="submit"/>
            <br>
            <br>
</form>

            <table border="4">
                <tr>
                    <th>Rollno</th>
                    <th>Name</th>
                    <th>Email</th>
                </tr>
        <tr>
        <?php 

          if(isset($_POST['submit']))
          {
            echo"<td>".$_POST['rollno']."</td>";
            echo"<td>".$_POST['name1']."</td>";
            echo"<td>".$_POST['email1']."</td>";
          }

        ?>
          </tr>

        </table>
    </body>
</html>