<html>
    <body>
        <form method="POST">
            Enter a character: <input type="text" name="char"/>
            <br>
            <input type="submit" name="submit"/>
            </form>

        <?php
            if(isset($_POST['submit']))
            {
                $char1 = $_POST['char'];
                
                if($char1 == 'A'||$char1=='E'||$char1=='I'||$char1=='O'||$char1=='U'||$char1=='a'||$char1=='e'||$char1=='i'||$char1=='o'||$char1=='u')
                {
                   echo "It is a vowel";
                }
                else
                {
                  echo "It is a consonant";
                }
        }
        ?>
    </body>
</html>
