<?php

 $num1 = 3;
 $num2 = 3;

 if($num1 != $num2)
 {
    $result = $num1 + $num2;
    echo $result;
 }

 elseif($num1 == $num2)
 {
    $result = 3*($num1 + $num2);
    echo $result;
 }

 else
 {
    echo "Invalid case";
 }

?>