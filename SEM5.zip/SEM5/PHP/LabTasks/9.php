<html>
    <body>
        <form method="POST">
            Enter a number: <input type="number" name="number"/>
            <br>
            <br>
            <input type="submit" name="square" value="Square"/>
            <br>
            <br>
            <input type="submit" name="fact" value="Factorial"/>
            <br>
            <br>
            <input type="submit" name="sqroot" value="Square root"/>
            <br>
            <br>
        </form>

        <?php
         
        if(isset($_POST['square']))
        {
            $num1 = $_POST['number'];

            $square = $num1 * $num1;

            echo "Square is: $square";
        }

        elseif(isset($_POST['fact']))
        {
          $num1 = $_POST['number'];
          $factorial = 1;

          for($i=1;$i<=$num1;$i++)
          {
            $factorial *= $i;
          }
          echo "Factorial is: $factorial";
        }

        elseif(isset($_POST['sqroot']))
        {
            $num1 = $_POST['number'];
            $sqroot = sqrt($num1);

            echo "Squareroot is: $sqroot";
        }
        ?>
    </body>
</html>