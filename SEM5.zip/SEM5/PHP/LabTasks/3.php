<html>
    <body>
        <form method="POST">
            Enter account number: <input type="number" name="acc"/>
            <br>
            <br>
            Enter amount to deposit : <input type="number" name="dep"/>
            <br>
            <br>
            Enter amount to withdraw: <input type="number" name="with"/>
            <br>
            <br>
            <input type="submit" name="deposit" value="deposit"/>
            <br>
            <br>
            <input type="submit" name="withdraw" value="withdraw"/>
            <br>
            <br>
        </form>

        <?php

class Bankaccount
{
    public $accno;
    public $depositamt;
    public $withdrawamt;
    public $currbalance;

     function __construct()
    {
        $this->accno = "";
        $this->depositamt = 0;
        $this->withdrawamt = 0;
        $this->currbalance = 0;
    }

    public function deposit()
    {
        if(isset($_POST['deposit']))
        {
            $this->accno = $_POST['acc'];
            $this->depositamt = $_POST['dep'];

            $this->currbalance += $this->depositamt;

            echo "Account number is: $this->accno <br>";
            echo "Current balance after deposit: $this->currbalance";
        }
    }

    public function withdraw()
    {
        if(isset($_POST['withdraw']))
        {
            $this->accno = $_POST['acc'];
            $this->withdrawamt = $_POST['with'];

            $this->currbalance -= $this->withdrawamt;

            echo "Account number is: $this->accno <br>";
            echo "Current balance after withdrawal: $this->currbalance";
        }
    }
}

$obj1 = new Bankaccount();

if(isset($_POST['deposit'])) {
    $obj1->deposit();
} else if(isset($_POST['withdraw'])) {
    $obj1->withdraw();
}

?>

    </body>
</html>