<html>
    <body>
        <form method="POST">
            Enter your age: <input type="text" name="age"/>
            <br>
            <input type="submit" name="submit"/>
            </form>

        <?php
            if(isset($_POST['submit']))
            {
                $age = $_POST['age'];
                
                if($age>=18)
                {
                   echo "Eligible to vote";
                }
                else
                {
                  echo "Not eligible to vote";
                }
        }
        ?>
    </body>
</html>
