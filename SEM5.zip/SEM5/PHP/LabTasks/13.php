<?php

          $num1 = 4;
          $factorial = 1;

          for($i=1;$i<=$num1;$i++)
          {
            $factorial *= $i;
          }
          echo "Factorial is: $factorial";

        ?>