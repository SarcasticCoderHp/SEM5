<?php

 $number = 5;

 $result =  ($number>30)?"Number greater than 30":
            (($number>20)?"Number greater than 20":
            (($number>10)?"Number greater than 10":
            "Number less than 10"));

            echo $result;
 ?>