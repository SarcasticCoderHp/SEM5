<html>
<body>
	<form method = "POST">
	Enter length of rectangle: <input type="number" name="len"/>
	<br>
	Enter width of rectangle: <input type="number" name="wid"/>
	<br>
	<input type="submit" name="submit">
</form>

<?php

 class rectangle
 {
 	public $length;
 	public $width;

 //	$this->length=$length;
 	//$this->width=$width;


 	function calAreaPeri($length,$width)
 	{
 		$area = $length * $width;
 	    $perimeter = $length * $width * 2;

        echo "Area is:$area";
        echo "<br>";
 		echo "Perimeter is:$perimeter";
 	}
 }

 	  if(isset($_POST['submit']))
 		{
 			$length = $_POST['len'];
 			$width = $_POST['wid'];
 		}

 $obj1 = new rectangle();
 $obj1->calAreaPeri($length,$width);

 ?>
</body>
</html>
