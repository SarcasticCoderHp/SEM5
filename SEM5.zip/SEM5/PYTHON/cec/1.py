print("1.Employee List operations")
print("2.Pyramid Creation")
print("3.Student Dictionary Operations")

choice = int(input("Enter your choice:"))

if(choice==1):
    e_id = int(input("Enter Employee Id:"))
    e_name = input("Enter Employee Name:")
    e_salary = int(input("Enter Employee Salary:"))
    e_desig = input("Enter Employee Designation:")
    
    employee_list = [e_id,e_name,e_salary,e_desig]
    print(employee_list)
    
    if(e_salary>30000):
        
        e_hra = 0.05 * e_salary
        e_medication = 0.10 * e_salary
        total_net_salary = e_salary - e_hra - e_medication
        print("Total net salary is:",total_net_salary)
      
    
    elif(e_salary>50000):
        
        e_hra = 0.07 * e_salary
        e_medication = 0.12 * e_salary
        total_net_salary = e_salary - e_hra - e_medication
        print("Total net salary is:",total_net_salary)
        
    elif(e_salary>80000):
        
        e_hra = 0.10 * e_salary
        e_medication = 0.15 * e_salary
        total_net_salary = e_salary - e_hra - e_medication
        print("Total net salary is:",total_net_salary)
        
elif(choice==2):
    
        start = int(input("Enter start value:"))
        end = int(input("Enter the end value:"))
        
        for i in range(start,end+1):
            print("* "*i)
            
elif(choice==3):
    
    name = input("Enter name of student:")
    rollno = int(input("Enter roll no of student:"))
    contact = int(input("Enter contact of student:"))
    email = input("Enter email of student:")
    
    Student = {"Name":name,"Rollno":rollno,"Contact":contact,"Email":email}
    
    if rollno in Student.values():
        print("Rollno is available.")
        print(Student)
    else:
         print("Rollno not available.")
        
else:
    print("Invalid choice")

        
        
                    
        
        
        
    
    
    
        
    