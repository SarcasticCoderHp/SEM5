str = input("Enter a string:")
print(str.title())