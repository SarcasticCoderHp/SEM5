str1 = "Welcome to Python"

print("Whole string is:",str1)
print("First character:",str1[0])
print("3rd to -1 char:",str1[3:-1])
print("4th to end char:",str1[4:])
print("Whole string 5 times:",str1*5)