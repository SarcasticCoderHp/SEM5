str = "Hello World"

print(str.count('l'))