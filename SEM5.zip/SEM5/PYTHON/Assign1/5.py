festivals = ['Navratri','Diwali','Holi','Rakshabandhan','Bakri Eid','Muharram']

print("Whole list:",festivals)
print("First Element:",festivals[0])
print("Elements from 2nd-3rd:",festivals[2:4])
print("Elements from 2nd-last:",festivals[2:])
print("Whole list 4 times:",festivals*4)