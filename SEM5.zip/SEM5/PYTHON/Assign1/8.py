print("1.Joomla")
print("2.Ruby on Rails")
print("3.Drupal")
print("4.Android")
print("5.IOS")

choice = int(input("Enter your choice:"))

if(choice==1):

    print("You selected Joomla")



elif(choice==2):

    print("You selected Ruby on Rails")



elif(choice==3):

    print("You selected Drupal")



elif(choice==4):

    print("You selected Android")



elif(choice==5):

    print("You selected IOS")



else:

    print("Invalid selection")
