a = 10
b = 3

addition = a + b
print(f"Addition: {addition}")

subtraction = a - b
print(f"Subtraction: {subtraction}")

multiplication = a * b
print(f"Multiplication: {multiplication}")

division = a / b
print(f"Division: {division}")

floor_division = a // b
print(f"Floor Division: {floor_division}")

modulus = a % b
print(f"Modulus: {modulus}")

exponentiation = a ** b
print(f"Exponentiation: {exponentiation}")

