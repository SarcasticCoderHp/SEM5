my_list = [1, 2, 3, 4, 5]
my_string = "Hello"

print("1 in my_list:", 1 in my_list)
print("6 in my_list:", 6 in my_list)

print("'H' in my_string:", 'H' in my_string)
print("'h' in my_string:", 'h' in my_string)

print("3 not in my_list:", 3 not in my_list)
print("'o' not in my_string:", 'o' not in my_string)
