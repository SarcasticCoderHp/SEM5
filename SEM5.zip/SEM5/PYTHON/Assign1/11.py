length = float(input("Enter length of rectangle:"))
width = float(input("Enter width of rectangle:"))

area = length*width
print("Area of rectangle:",area)

side = int(input("Enter side of square:"))
area1 = side*side
print("Area of square:",area1)