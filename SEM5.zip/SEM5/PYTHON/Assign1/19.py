#Assignment operators

a = 3
b = 5

a+=b
'''a-=b
a*=b
a/=b
a%=b
a//=b
a**=b
a&=b
a!=b
a>>=b
a<<=b'''

print(a)