a = 5
b = 5
c = [1, 2, 3]
d = [1, 2, 3]

print("a is b:", a is b)
print("a is not b:", a is not b)

print("c is d:", c is d)
print("c is not d:", c is not d)
