#STRING FUNCTIONS

str1 = "HelloWorld"
print(str1.capitalize())

str2 = "This is string"
sub = "i"
print(str2.count(sub,0,len(str2)))

str3 = "Example of string"
suffix = "string"
print(str3.endswith(suffix))
print(str3.startswith(suffix))

str4 = "Hello from strings"
exe1 = "from"
print(str4.find(exe1))
print(str4.index("llo",0,len(str4)))

str5 = "ty2018"
print(str5.isalnum())

str6 = "this1"
print(str6.isalpha())

str7 = "123456"
print(str6.isdigit())

str8 = "helloworld"
print(str8.islower())

str9 = "HELLO"
print(str9.isupper())

str10 = " "
print(str10.isspace())

str11 = "GLS"
print(len(str11))

str12 = "HelloworlD"
print(str12.lower())
print(str12.upper())

str13 = "Gls Uniersity"
print(str13.swapcase())

str14 = "  THIS IS STRING  "
str15 = "8888this is string"
print(str14.lstrip())
print(str15.lstrip('8'))

str16 = "  THIS IS STRING  "
str17 = "this is string888888"
print(str16.rstrip())
print(str17.rstrip('8'))