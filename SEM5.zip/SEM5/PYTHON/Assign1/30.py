str3 = input("Enter a string:")
startsuffix = input("Enter a suffix to find starts with:")
endsuffix = input("Enter a suffix to find ends with:")

print(str3.startswith(startsuffix))
print(str3.endswith(endsuffix))
