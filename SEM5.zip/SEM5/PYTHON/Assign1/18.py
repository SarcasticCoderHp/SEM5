a = 10
b = 3

bitwise_and = a & b
print("Bitwise AND:", bitwise_and)

bitwise_or = a | b
print("Bitwise OR:", bitwise_or)

bitwise_xor = a ^ b
print("Bitwise XOR:", bitwise_xor)

bitwise_not_a = ~a
print("Bitwise NOT (a):", bitwise_not_a)

bitwise_not_b = ~b
print("Bitwise NOT (b):", bitwise_not_b)

left_shift = a << 1
print("Bitwise Left Shift (a << 1):", left_shift)

right_shift = a >> 1
print("Bitwise Right Shift (a >> 1):", right_shift)
