a = int(input("Enter a integer value:"))
b = float(input("Enter a float value:"))
c = complex(input("Enter a complex value:"))

print(type(a))
print(type(b))
print(type(c))