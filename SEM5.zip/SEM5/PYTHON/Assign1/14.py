str = input("Enter a string:")
print("Length of string is:",len(str))