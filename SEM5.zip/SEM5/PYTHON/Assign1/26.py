print("1. Arithmetic Operation")
print("2. Identity Operator Operation")
print("3. Logical Operation")
print("4. Membership Operator Operation")
print("5. Exit")

choice = input("Enter your choice: ")
if choice == '1':
        print("1. Addition")
        print("2. Subtraction")
        print("3. Multiplication")
        print("4. Division")
        arithmetic_choice = input("Enter your choice: ")

        num1 = float(input("Enter first number: "))
        num2 = float(input("Enter second number: "))

        if arithmetic_choice == '1':
            result = num1 + num2
            print("Result:", result)
        elif arithmetic_choice == '2':
            result = num1 - num2
            print("Result:", result)
        elif arithmetic_choice == '3':
            result = num1 * num2
            print("Result:", result)
        elif arithmetic_choice == '4':
            if num2 == 0:
                print("Error! Division by zero.")
            else:
                result = num1 / num2
                print("Result:", result)
        else:
            print("Invalid choice")

elif choice == '2':
        var1 = input("Enter first variable: ")
        var2 = input("Enter second variable: ")

        if var1 == var2:
            print("Variables are identical")
        else:
            print("Variables are not identical")

elif choice == '3':
        print("1. AND")
        print("2. OR")
        print("3. NOT")
        logical_choice = input("Enter your choice: ")

        if logical_choice == '1':
            bool1 = bool(input("Enter first boolean: "))
            bool2 = bool(input("Enter second boolean: "))
            result = bool1 and bool2
            print("Result:", result)
        elif logical_choice == '2':
            bool1 = bool(input("Enter first boolean : "))
            bool2 = bool(input("Enter second boolean : "))
            result = bool1 or bool2
            print("Result:", result)
        elif logical_choice == '3':
            bool1 = bool(input("Enter a boolean: "))
            result = not bool1
            print("Result:", result)
        else:
            print("Invalid choice")

   
elif choice == '4':
        list1 = input("Enter a list (comma-separated elements): ").split(',')
        element = input("Enter an element to check membership: ")

        if element in list1:
            print(f"{element} is present in the list")
        else:
            print(f"{element} is not present in the list")

elif choice == '5':
        print("Exit")

else:
        print("Invalid choice. Please enter a valid option.")
