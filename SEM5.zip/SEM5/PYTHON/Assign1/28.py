str14 = "  THIS IS STRING  "
str15 = "8888this is string"
print(str14.lstrip())
print(str15.lstrip('8'))

str16 = "  THIS IS STRING  "
str17 = "this is string888888"
print(str16.rstrip())
print(str17.rstrip('8'))