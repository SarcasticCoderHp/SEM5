str = input("Enter a string:")
str1 = input("Enter string to find:")

position = str.find(str1)
print("String found a position:",position)