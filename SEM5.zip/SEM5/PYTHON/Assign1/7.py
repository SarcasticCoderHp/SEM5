vegetables = ('Potato','Brinjal','Tomato','Cabbage','Cauliflower')

print("Whole tuple:",vegetables)
print("Elements from 2nd-4th:",vegetables[2:5])
print("Elements from 2nd-last:",vegetables[2:])
print("Whole tuple twice:",vegetables*2)