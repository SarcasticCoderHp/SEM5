print("Enter 5 subject marks:")
a = float(input())
b = float(input())
c = float(input())
d = float(input())
e = float(input())

total = a+b+c+d+e
percent = (total*100)/500

print("Percentage is:",percent)