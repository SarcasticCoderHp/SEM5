string_num = "123"
integer_num=int(string_num)
print(integer_num)

'''integer_num = 123
float_num=float(integer_num)
print(float_num)

tuple1 = (1,2,3)
list1 = list(tuple1)
print(list1)

string1 = "Hello"
list1 = list(string1)
print(list1)

list1 = [1,2,3]
tuple1 = tuple(list1)
print(tuple1)'''






