a = int(input("Enter first number:"))
b = int(input("Enter second number:"))

print("Numbers before swapping:",a,b)

temp = a
a = b
b = temp

print("Numbers after swapping:",a,b)