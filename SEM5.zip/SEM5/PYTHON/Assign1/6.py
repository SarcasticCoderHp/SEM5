fruit = {'apple':'red','mango':'yellow','kiwi':'green','grape':'purple'}

print(fruit.keys())
print(fruit.values())