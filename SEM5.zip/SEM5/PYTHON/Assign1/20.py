a = True
b = False

logical_and = a and b
print("Logical AND:", logical_and)

logical_or = a or b
print("Logical OR:", logical_or)

logical_not_a = not a
print("Logical NOT (a):", logical_not_a)

logical_not_b = not b
print("Logical NOT (b):", logical_not_b)
